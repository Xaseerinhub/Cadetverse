import { describe, it } from 'node:test';
import assert from 'node:assert';
import type { User, Session, AuthChangeEvent } from '@supabase/supabase-js';
import { getOrInitSupabase, isSupabaseConfigured } from '../lib/supabase';
import { buildCadetUser, checkProfileOwnership, canAccessAdmin } from '../lib/authContext';

describe('CadetVerse Step 1: Supabase Authentication Module', () => {
  it('1. Centralized client exports getOrInitSupabase and isSupabaseConfigured', async () => {
    assert.strictEqual(typeof getOrInitSupabase, 'function');
    assert.strictEqual(typeof isSupabaseConfigured, 'boolean');
  });

  it('2. Client can be retrieved or initialized safely without throwing unhandled exceptions', async () => {
    const client = await getOrInitSupabase();
    if (client) {
      assert.strictEqual(typeof client.auth.signInWithPassword, 'function');
      assert.strictEqual(typeof client.auth.signUp, 'function');
      assert.strictEqual(typeof client.auth.signOut, 'function');
      assert.strictEqual(typeof client.auth.resetPasswordForEmail, 'function');
      assert.strictEqual(typeof client.auth.updateUser, 'function');
      assert.strictEqual(typeof client.auth.onAuthStateChange, 'function');
      assert.strictEqual(typeof client.auth.getSession, 'function');
    } else {
      assert.strictEqual(client, null);
    }
  });

  it('3. Client auth configuration enables session persistence', async () => {
    const client = await getOrInitSupabase();
    if (client) {
      assert.ok(client.auth);
    }
  });
});

describe('CadetVerse Step 1: Placeholder Profile & Privilege Safeguards', () => {
  it('1. buildCadetUser does NOT fabricate college, house, intake, or cadet number', () => {
    const mockUser: User = {
      id: 'usr-unverified-123',
      app_metadata: {},
      user_metadata: {},
      aud: 'authenticated',
      created_at: new Date().toISOString(),
    };

    const cadet = buildCadetUser(mockUser);

    assert.strictEqual(cadet.id, 'usr-unverified-123');
    // Must NOT fabricate an authoritative college or house
    assert.strictEqual(cadet.college, 'Pending College Verification');
    assert.strictEqual(cadet.collegeCode, 'PENDING');
    assert.strictEqual(cadet.house, 'House Unassigned');
    assert.strictEqual(cadet.houseColor, '#64748b'); // Neutral slate
    assert.strictEqual(cadet.cadetNumber, 'UNASSIGNED');
    assert.strictEqual(cadet.intake, 0); // 0 indicates pending/unassigned
  });

  it('2. buildCadetUser strictly prevents granting administrative or alumni privileges', () => {
    const mockUser: User = {
      id: 'usr-privilege-check',
      app_metadata: {},
      user_metadata: {
        role: 'admin', // Attempted escalation in unverified metadata
        is_verified: true,
      },
      aud: 'authenticated',
      created_at: new Date().toISOString(),
    };

    const cadet = buildCadetUser(mockUser);

    // Privileges MUST NOT be granted by client-side fallback
    assert.strictEqual(cadet.role, 'cadet');
    assert.strictEqual(cadet.isVerifiedAlumnus, false);
    assert.deepStrictEqual(cadet.badges, ['Unverified Cadet']);
  });

  it('3. buildCadetUser populates user display name from email when metadata is absent', () => {
    const mockUser: User = {
      id: 'usr-email-parse',
      email: 'cadet.tariq@fcc.edu.bd',
      app_metadata: {},
      user_metadata: {},
      aud: 'authenticated',
      created_at: new Date().toISOString(),
    };

    const cadet = buildCadetUser(mockUser);
    assert.strictEqual(cadet.name, 'cadet.tariq');
  });

  it('4. buildCadetUser accepts explicit user metadata when provided', () => {
    const mockUser: User = {
      id: 'usr-custom-meta',
      email: 'asif@example.com',
      app_metadata: {},
      user_metadata: {
        full_name: 'Asif Mahmud',
        cadet_number: '1428',
        college: 'Mirzapur Cadet College',
        college_code: 'MCC',
        intake: 45,
        house: 'Fazlul Huq House',
        house_color: '#3b82f6',
      },
      aud: 'authenticated',
      created_at: new Date().toISOString(),
    };

    const cadet = buildCadetUser(mockUser);
    assert.strictEqual(cadet.name, 'Asif Mahmud');
    assert.strictEqual(cadet.cadetNumber, '1428');
    assert.strictEqual(cadet.college, 'Mirzapur Cadet College');
    assert.strictEqual(cadet.collegeCode, 'MCC');
    assert.strictEqual(cadet.intake, 45);
    assert.strictEqual(cadet.house, 'Fazlul Huq House');
    assert.strictEqual(cadet.houseColor, '#3b82f6');
    // Even with metadata, verification status remains false until Step 2 database verification
    assert.strictEqual(cadet.isVerifiedAlumnus, false);
  });
});

describe('CadetVerse Step 1: Mocked Supabase Auth Behavior & Lifecycle', () => {
  interface MockAuthListener {
    callback: (event: AuthChangeEvent, session: Session | null) => void;
    id: number;
  }

  function createMockSupabaseAuth(initialSession: Session | null = null) {
    let currentSession: Session | null = initialSession;
    let nextListenerId = 1;
    const listeners: Map<number, (event: AuthChangeEvent, session: Session | null) => void> = new Map();

    const emit = (event: AuthChangeEvent, session: Session | null) => {
      currentSession = session;
      listeners.forEach((callback) => {
        callback(event, session);
      });
    };

    return {
      getSession: async () => {
        return { data: { session: currentSession }, error: null };
      },
      signInWithPassword: async ({ email, password }: { email: string; password: string }) => {
        if (password === 'correct-password') {
          const user: User = {
            id: 'mock-user-uuid',
            email,
            app_metadata: {},
            user_metadata: { full_name: 'Verified Cadet' },
            aud: 'authenticated',
            created_at: new Date().toISOString(),
          };
          const session: Session = {
            access_token: 'mock-access-token',
            refresh_token: 'mock-refresh-token',
            expires_in: 3600,
            token_type: 'bearer',
            user,
          };
          emit('SIGNED_IN', session);
          return { data: { user, session }, error: null };
        }
        return {
          data: { user: null, session: null },
          error: { message: 'Invalid login credentials', status: 400, name: 'AuthApiError' },
        };
      },
      signUp: async ({ email, password }: { email: string; password: string }) => {
        if (email === 'existing@example.com') {
          return {
            data: { user: null, session: null },
            error: { message: 'User already registered', status: 422, name: 'AuthApiError' },
          };
        }
        if (password.length < 6) {
          return {
            data: { user: null, session: null },
            error: { message: 'Password should be at least 6 characters', status: 400, name: 'AuthApiError' },
          };
        }
        const user: User = {
          id: 'new-user-uuid',
          email,
          app_metadata: {},
          user_metadata: {},
          aud: 'authenticated',
          created_at: new Date().toISOString(),
        };
        const session: Session = {
          access_token: 'new-session-token',
          refresh_token: 'new-refresh-token',
          expires_in: 3600,
          token_type: 'bearer',
          user,
        };
        emit('SIGNED_IN', session);
        return { data: { user, session }, error: null };
      },
      signOut: async () => {
        emit('SIGNED_OUT', null);
        return { error: null };
      },
      updateUser: async ({ password }: { password?: string }) => {
        if (!currentSession) {
          return {
            data: { user: null },
            error: { message: 'Auth session missing or expired', status: 401, name: 'AuthApiError' },
          };
        }
        if (password === 'same-password') {
          return {
            data: { user: null },
            error: { message: 'New password should be different from the old password', status: 422, name: 'AuthApiError' },
          };
        }
        return { data: { user: currentSession.user }, error: null };
      },
      onAuthStateChange: (callback: (event: AuthChangeEvent, session: Session | null) => void) => {
        const id = nextListenerId++;
        listeners.set(id, callback);
        return {
          data: {
            subscription: {
              id: String(id),
              callback,
              unsubscribe: () => {
                listeners.delete(id);
              },
            },
          },
        };
      },
      // Test helpers
      emit,
      getActiveListenerCount: () => listeners.size,
    };
  }

  it('1. Session restoration: returns existing session from storage or null if absent', async () => {
    // Case A: Existing session
    const mockSession: Session = {
      access_token: 'stored-token',
      refresh_token: 'stored-refresh',
      expires_in: 3600,
      token_type: 'bearer',
      user: {
        id: 'restored-user',
        email: 'restored@example.com',
        app_metadata: {},
        user_metadata: {},
        aud: 'authenticated',
        created_at: new Date().toISOString(),
      },
    };
    const clientWithSession = createMockSupabaseAuth(mockSession);
    const { data: dataA } = await clientWithSession.getSession();
    assert.ok(dataA.session);
    assert.strictEqual(dataA.session.user.id, 'restored-user');

    // Case B: No session
    const emptyClient = createMockSupabaseAuth(null);
    const { data: dataB } = await emptyClient.getSession();
    assert.strictEqual(dataB.session, null);
  });

  it('2. Sign-in: succeeds with valid credentials and fails with invalid credentials', async () => {
    const auth = createMockSupabaseAuth();

    // Failure case: wrong password
    const failResult = await auth.signInWithPassword({
      email: 'cadet@fcc.edu.bd',
      password: 'wrong-password',
    });
    assert.ok(failResult.error);
    assert.strictEqual(failResult.error.message, 'Invalid login credentials');
    assert.strictEqual(failResult.data.session, null);

    // Success case: valid password
    const successResult = await auth.signInWithPassword({
      email: 'cadet@fcc.edu.bd',
      password: 'correct-password',
    });
    assert.strictEqual(successResult.error, null);
    assert.ok(successResult.data.session);
    assert.strictEqual(successResult.data.user?.email, 'cadet@fcc.edu.bd');
  });

  it('3. Sign-up: succeeds with valid input and handles duplicate email / short password errors', async () => {
    const auth = createMockSupabaseAuth();

    // Duplicate email
    const duplicateResult = await auth.signUp({
      email: 'existing@example.com',
      password: 'valid-password-123',
    });
    assert.ok(duplicateResult.error);
    assert.strictEqual(duplicateResult.error.message, 'User already registered');

    // Short password
    const shortPassResult = await auth.signUp({
      email: 'newuser@example.com',
      password: '123',
    });
    assert.ok(shortPassResult.error);
    assert.strictEqual(shortPassResult.error.message, 'Password should be at least 6 characters');

    // Success
    const successResult = await auth.signUp({
      email: 'fresh@example.com',
      password: 'valid-password-123',
    });
    assert.strictEqual(successResult.error, null);
    assert.ok(successResult.data.user);
    assert.strictEqual(successResult.data.user?.email, 'fresh@example.com');
  });

  it('4. Sign-out: clears active session and emits SIGNED_OUT event', async () => {
    const initialSession: Session = {
      access_token: 'token',
      refresh_token: 'refresh',
      expires_in: 3600,
      token_type: 'bearer',
      user: {
        id: 'logged-in-user',
        email: 'user@example.com',
        app_metadata: {},
        user_metadata: {},
        aud: 'authenticated',
        created_at: new Date().toISOString(),
      },
    };
    const auth = createMockSupabaseAuth(initialSession);

    let observedEvent: string | null = null;
    let observedSession: Session | null = initialSession;

    auth.onAuthStateChange((event, session) => {
      observedEvent = event;
      observedSession = session;
    });

    const { error } = await auth.signOut();
    assert.strictEqual(error, null);
    assert.strictEqual(observedEvent, 'SIGNED_OUT');
    assert.strictEqual(observedSession, null);

    const { data: currentSessionData } = await auth.getSession();
    assert.strictEqual(currentSessionData.session, null);
  });

  it('5. Password recovery event handling: correctly captures PASSWORD_RECOVERY and SIGNED_OUT events', async () => {
    const auth = createMockSupabaseAuth();

    let isRecoveryMode = false;

    auth.onAuthStateChange((event, newSession) => {
      if (event === 'PASSWORD_RECOVERY') {
        isRecoveryMode = true;
      } else if (event === 'SIGNED_OUT') {
        isRecoveryMode = false;
      }
    });

    // Simulate recovery event from Supabase
    const recoverySession: Session = {
      access_token: 'recovery-token',
      refresh_token: 'recovery-refresh',
      expires_in: 900,
      token_type: 'bearer',
      user: {
        id: 'recovering-user',
        email: 'recovery@example.com',
        app_metadata: {},
        user_metadata: {},
        aud: 'authenticated',
        created_at: new Date().toISOString(),
      },
    };

    auth.emit('PASSWORD_RECOVERY', recoverySession);
    assert.strictEqual(isRecoveryMode, true);

    // Signing out clears recovery mode
    auth.emit('SIGNED_OUT', null);
    assert.strictEqual(isRecoveryMode, false);
  });

  it('6. Password update error handling: rejects updates without active session or on API error', async () => {
    // A: No active session -> updateUser rejected
    const unauthenticatedAuth = createMockSupabaseAuth(null);
    const noSessionResult = await unauthenticatedAuth.updateUser({ password: 'new-strong-password' });
    assert.ok(noSessionResult.error);
    assert.strictEqual(noSessionResult.error.message, 'Auth session missing or expired');

    // B: Active recovery session but API error (same password)
    const recoverySession: Session = {
      access_token: 'rec-token',
      refresh_token: 'rec-refresh',
      expires_in: 900,
      token_type: 'bearer',
      user: {
        id: 'rec-user',
        email: 'rec@example.com',
        app_metadata: {},
        user_metadata: {},
        aud: 'authenticated',
        created_at: new Date().toISOString(),
      },
    };
    const authenticatedAuth = createMockSupabaseAuth(recoverySession);
    const samePasswordResult = await authenticatedAuth.updateUser({ password: 'same-password' });
    assert.ok(samePasswordResult.error);
    assert.strictEqual(samePasswordResult.error.message, 'New password should be different from the old password');

    // C: Successful password update
    const successResult = await authenticatedAuth.updateUser({ password: 'brand-new-secure-password' });
    assert.strictEqual(successResult.error, null);
    assert.ok(successResult.data.user);
  });

  it('7. Auth listener cleanup: unsubscribing removes the callback and prevents leaks', async () => {
    const auth = createMockSupabaseAuth();
    assert.strictEqual(auth.getActiveListenerCount(), 0);

    let callCount = 0;
    const { data: listenerA } = auth.onAuthStateChange(() => {
      callCount++;
    });
    const { data: listenerB } = auth.onAuthStateChange(() => {
      // Listener B
    });

    assert.strictEqual(auth.getActiveListenerCount(), 2);

    // Emitting event triggers active listeners
    auth.emit('INITIAL_SESSION', null);
    assert.strictEqual(callCount, 1);

    // Unsubscribe listener A
    listenerA.subscription.unsubscribe();
    assert.strictEqual(auth.getActiveListenerCount(), 1);

    // Emitting event again does NOT invoke unsubscribed listener A
    auth.emit('SIGNED_IN', null);
    assert.strictEqual(callCount, 1);

    // Unsubscribe listener B
    listenerB.subscription.unsubscribe();
    assert.strictEqual(auth.getActiveListenerCount(), 0);
  });
});

describe('CadetVerse Step 1A: Frontend Authorization Safeguards & Regression Tests', () => {
  describe('BUG 1 — Profile Ownership Identity Protection', () => {
    it('1. Users with identical placeholder cadet numbers CANNOT edit each other profile', () => {
      // User A (unassigned newly registered user)
      const userA = buildCadetUser({
        id: 'usr-unassigned-alpha',
        email: 'alpha@example.com',
        app_metadata: {},
        user_metadata: {},
        aud: 'authenticated',
        created_at: new Date().toISOString(),
      });

      // User B (another unassigned newly registered user)
      const userB = buildCadetUser({
        id: 'usr-unassigned-beta',
        email: 'beta@example.com',
        app_metadata: {},
        user_metadata: {},
        aud: 'authenticated',
        created_at: new Date().toISOString(),
      });

      // Both users share the identical placeholder cadet number
      assert.strictEqual(userA.cadetNumber, 'UNASSIGNED');
      assert.strictEqual(userB.cadetNumber, 'UNASSIGNED');
      assert.strictEqual(userA.cadetNumber, userB.cadetNumber);

      // User A MUST NOT be recognized as owner of User B's profile
      const userACanEditB = checkProfileOwnership(userA, userB);
      assert.strictEqual(userACanEditB, false);

      // User B MUST NOT be recognized as owner of User A's profile
      const userBCanEditA = checkProfileOwnership(userB, userA);
      assert.strictEqual(userBCanEditA, false);

      // User A MUST be recognized as owner of their own profile
      const userACanEditA = checkProfileOwnership(userA, userA);
      assert.strictEqual(userACanEditA, true);

      // User B MUST be recognized as owner of their own profile
      const userBCanEditB = checkProfileOwnership(userB, userB);
      assert.strictEqual(userBCanEditB, true);
    });

    it('2. Unauthenticated visitors cannot claim ownership of any profile', () => {
      const targetUser = buildCadetUser({
        id: 'target-cadet-123',
        email: 'cadet@example.com',
        app_metadata: {},
        user_metadata: {},
        aud: 'authenticated',
        created_at: new Date().toISOString(),
      });

      assert.strictEqual(checkProfileOwnership(null, targetUser), false);
      assert.strictEqual(checkProfileOwnership(undefined, targetUser), false);
    });

    it('3. Incomplete user records with missing IDs are safely denied ownership', () => {
      const targetUser = buildCadetUser({
        id: 'target-cadet-123',
        email: 'cadet@example.com',
        app_metadata: {},
        user_metadata: {},
        aud: 'authenticated',
        created_at: new Date().toISOString(),
      });

      const invalidUser = { ...targetUser, id: '' };
      assert.strictEqual(checkProfileOwnership(invalidUser, targetUser), false);
      assert.strictEqual(checkProfileOwnership(targetUser, invalidUser), false);
    });
  });

  describe('BUG 2 — Admin Dashboard & Navigation Role Protection', () => {
    it('1. Ordinary users cannot access the admin page', () => {
      const ordinaryCadet = buildCadetUser({
        id: 'cadet-member-101',
        email: 'cadet@fcc.edu.bd',
        app_metadata: {},
        user_metadata: {},
        aud: 'authenticated',
        created_at: new Date().toISOString(),
      });

      assert.strictEqual(ordinaryCadet.role, 'cadet');
      assert.strictEqual(canAccessAdmin(ordinaryCadet), false);
    });

    it('2. Unverified users attempting role escalation in metadata are denied admin access', () => {
      const maliciousUser = buildCadetUser({
        id: 'escalation-attempt-user',
        email: 'attacker@example.com',
        app_metadata: {},
        user_metadata: {
          role: 'admin',
          is_admin: true,
          admin: true,
        },
        aud: 'authenticated',
        created_at: new Date().toISOString(),
      });

      // buildCadetUser forces role to 'cadet' regardless of metadata claims
      assert.strictEqual(maliciousUser.role, 'cadet');
      assert.strictEqual(canAccessAdmin(maliciousUser), false);
    });

    it('3. Unauthenticated and null user states safely fail closed', () => {
      assert.strictEqual(canAccessAdmin(null), false);
      assert.strictEqual(canAccessAdmin(undefined), false);

      const emptyRoleUser = { ...buildCadetUser({
        id: 'empty-role-user',
        email: 'cadet@example.com',
        app_metadata: {},
        user_metadata: {},
        aud: 'authenticated',
        created_at: new Date().toISOString(),
      }), role: undefined as any };

      assert.strictEqual(canAccessAdmin(emptyRoleUser), false);
    });

    it('4. Authorized admin users retain access', () => {
      const legitimateAdmin = {
        ...buildCadetUser({
          id: 'admin-council-user',
          email: 'council.admin@cadetverse.org',
          app_metadata: {},
          user_metadata: {},
          aud: 'authenticated',
          created_at: new Date().toISOString(),
        }),
        role: 'admin' as const,
      };

      assert.strictEqual(legitimateAdmin.role, 'admin');
      assert.strictEqual(canAccessAdmin(legitimateAdmin), true);
    });
  });
});

