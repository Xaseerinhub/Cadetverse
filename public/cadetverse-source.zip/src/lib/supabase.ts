/**
 * CadetVerse Centralized Supabase Client
 * 
 * Supports dual initialization:
 * 1. Build-time / static environment variables (import.meta.env.VITE_SUPABASE_URL, etc.)
 * 2. Runtime server configuration fetched via GET /api/config
 * 
 * Preserves local mock mode and handles missing credentials gracefully.
 * STRICTLY NO service-role or secret keys are ever imported or exposed here.
 */

import { createClient, SupabaseClient } from '@supabase/supabase-js';

const getStaticEnv = (key: string): string | undefined => {
  if (typeof import.meta !== 'undefined' && import.meta.env && typeof import.meta.env[key] === 'string') {
    return import.meta.env[key];
  }
  if (typeof process !== 'undefined' && process.env && typeof process.env[key] === 'string') {
    return process.env[key];
  }
  return undefined;
};

/**
 * Normalizes the Supabase project base URL by stripping any accidental subpaths
 * such as `/rest/v1`, `/rest/v1/`, `/rest`, or trailing slashes.
 * Supabase SDK requires the root project URL (e.g. https://xyz.supabase.co).
 */
export function normalizeSupabaseUrl(rawUrl: string | undefined | null): string | null {
  if (!rawUrl || typeof rawUrl !== 'string') return null;
  const trimmed = rawUrl.trim();
  if (!trimmed) return null;
  return trimmed
    .replace(/\/rest\/v1\/?$/, '')
    .replace(/\/rest\/?$/, '')
    .replace(/\/auth\/v1\/?$/, '')
    .replace(/\/$/, '');
}

const rawStaticUrl = getStaticEnv('VITE_SUPABASE_URL');
const rawStaticKey = getStaticEnv('VITE_SUPABASE_ANON_KEY');
const staticUrl = normalizeSupabaseUrl(rawStaticUrl);
const staticKey = rawStaticKey ? rawStaticKey.trim() : undefined;

export let isSupabaseConfigured: boolean = Boolean(
  staticUrl && staticKey
);

export let supabase: SupabaseClient | null = null;

function createClientInstance(url: string, key: string): SupabaseClient | null {
  const normalizedUrl = normalizeSupabaseUrl(url);
  const normalizedKey = key ? key.trim() : '';

  if (!normalizedUrl || !normalizedKey) {
    return null;
  }

  try {
    return createClient(normalizedUrl, normalizedKey, {
      auth: {
        persistSession: true,
        autoRefreshToken: true,
        detectSessionInUrl: true,
      },
    });
  } catch (error) {
    console.warn('[CadetVerse] Warning: Failed to initialize Supabase client:', error);
    return null;
  }
}

// Initialize immediately if static environment variables are present
if (isSupabaseConfigured && staticUrl && staticKey) {
  supabase = createClientInstance(staticUrl, staticKey);
}

/**
 * Asynchronously loads Supabase credentials from the server's /api/config route.
 * Used when secrets are injected on the server container rather than built into client bundle.
 */
export async function initSupabaseFromConfig(): Promise<SupabaseClient | null> {
  if (supabase) {
    return supabase;
  }

  // Only execute in browser environments where fetch is available
  if (typeof window === 'undefined') {
    return null;
  }

  try {
    const res = await fetch('/api/config');
    if (!res.ok) {
      return null;
    }

    const data = await res.json();
    if (data && data.isConfigured && data.supabaseUrl && data.supabaseAnonKey) {
      supabase = createClientInstance(data.supabaseUrl, data.supabaseAnonKey);
      if (supabase) {
        isSupabaseConfigured = true;
      }
      return supabase;
    }
  } catch (err) {
    // Graceful fallback to mock mode
    console.info('[CadetVerse] Operating in local mock mode (no active backend config).');
  }

  return null;
}

/**
 * Ensures the Supabase client is initialized (awaiting /api/config if needed)
 * and returns it.
 */
export async function getOrInitSupabase(): Promise<SupabaseClient | null> {
  if (supabase) {
    return supabase;
  }
  return await initSupabaseFromConfig();
}

// In browser environments, attempt background configuration loading if not statically set
if (typeof window !== 'undefined' && !supabase) {
  initSupabaseFromConfig().catch(() => {});
}

/**
 * Helper to obtain the active Supabase client.
 * Throws a descriptive error if accessed when Supabase has not been configured.
 */
export function getSupabaseClient(): SupabaseClient {
  if (!supabase) {
    throw new Error(
      '[CadetVerse] Supabase client is not configured. Please ensure VITE_SUPABASE_URL and VITE_SUPABASE_ANON_KEY are set.'
    );
  }
  return supabase;
}
