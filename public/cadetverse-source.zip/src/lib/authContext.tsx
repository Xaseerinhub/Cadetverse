/**
 * CadetVerse Authentication Context
 * 
 * Provides centralized Supabase authentication state and actions:
 * - Session restoration and persistent session management
 * - Email / password sign-up and sign-in
 * - Sign-out
 * - Password recovery email trigger and password update flow
 * - In-memory CadetUser conversion without database table dependence
 */

import React, { createContext, useContext, useEffect, useState, useMemo } from 'react';
import type { User, Session, AuthError } from '@supabase/supabase-js';
import { getOrInitSupabase, isSupabaseConfigured as initialConfiguredStatus } from './supabase';
import type { CadetUser, CadetCollegeCode } from '../types';

export interface AuthContextType {
  user: User | null;
  session: Session | null;
  cadetUser: CadetUser | null;
  loading: boolean;
  isConfigured: boolean;
  isPasswordRecovery: boolean;
  signInWithEmail: (email: string, password: string) => Promise<{ error: AuthError | Error | null }>;
  signUpWithEmail: (email: string, password: string, fullName?: string) => Promise<{ error: AuthError | Error | null; user: User | null }>;
  signOut: () => Promise<{ error: AuthError | Error | null }>;
  sendPasswordResetEmail: (email: string) => Promise<{ error: AuthError | Error | null }>;
  updateUserPassword: (newPassword: string) => Promise<{ error: AuthError | Error | null }>;
  clearRecoveryMode: () => void;
}

const AuthContext = createContext<AuthContextType | undefined>(undefined);

/**
 * Derives a temporary in-memory CadetUser object from the authenticated Supabase user.
 * 
 * IMPORTANT: In Step 1 (Authentication), database profile and membership tables
 * do not exist yet (scheduled for Step 2). Therefore:
 * - NO fabricated college, house, intake, or cadet number is presented as authoritative.
 * - Temporary placeholders are explicitly marked as "Pending Verification" / "Unassigned".
 * - Role is strictly baseline 'cadet' and isVerifiedAlumnus is false, ensuring NO privileges are granted.
 */
export function buildCadetUser(user: User): CadetUser {
  const metadata = user.user_metadata || {};
  const emailName = user.email ? user.email.split('@')[0] : 'Cadet User';
  const name = metadata.full_name || metadata.display_name || emailName;

  // Use authoritative metadata only if explicitly provided; otherwise use unambiguous placeholders
  const college = metadata.college ? String(metadata.college) : 'Pending College Verification';
  const collegeCode = (metadata.college_code as CadetCollegeCode) || 'PENDING';
  const intake = typeof metadata.intake === 'number' ? metadata.intake : (Number(metadata.intake) || 0);
  const house = metadata.house ? String(metadata.house) : 'House Unassigned';
  const cadetNumber = metadata.cadet_number ? String(metadata.cadet_number) : 'UNASSIGNED';

  return {
    id: user.id,
    name: String(name),
    cadetNumber,
    college,
    collegeCode,
    intake,
    house,
    houseColor: metadata.house_color || '#64748b', // Neutral slate, not claiming an authoritative house colour
    avatar: metadata.avatar_url || 'https://images.unsplash.com/photo-1535713875002-d1d0cf377fde?auto=format&fit=crop&w=400&q=80',
    coverImage: '/src/assets/images/cadet_campus_grounds_1794029062449.jpg',
    role: 'cadet', // Baseline role strictly with NO administrative or privileged rights
    profession: metadata.profession ? String(metadata.profession) : 'Cadet Member (Unverified)',
    location: metadata.location ? String(metadata.location) : 'Bangladesh',
    bio: metadata.bio ? String(metadata.bio) : `CadetVerse Member (${user.email || 'authenticated'}) - Verification Pending`,
    joinedDate: user.created_at
      ? new Date(user.created_at).toLocaleDateString('en-US', { month: 'short', year: 'numeric' })
      : 'Recently Joined',
    isVerifiedAlumnus: false, // Strictly false: never grants verified alumnus status as a placeholder
    stats: {
      posts: 0,
      connections: 0,
      batchmatesCount: 0,
    },
    badges: ['Unverified Cadet'],
  };
}

/**
 * Authoritative check to verify whether currentUser owns targetUser profile.
 * Strictly compares unique user IDs, preventing false positives when both users
 * have placeholder cadet numbers (e.g. 'UNASSIGNED').
 */
export function checkProfileOwnership(
  currentUser: CadetUser | null | undefined,
  targetUser: CadetUser | null | undefined
): boolean {
  if (!currentUser?.id || !targetUser?.id) return false;
  return currentUser.id === targetUser.id;
}

/**
 * Authoritative check to determine if a user possesses admin council access.
 * Strictly validates that role is 'admin', safely handling null or unverified users.
 */
export function canAccessAdmin(
  currentUser: CadetUser | null | undefined
): boolean {
  if (!currentUser) return false;
  return currentUser.role === 'admin';
}

/**
 * Helper to inspect whether the URL indicates a password recovery redirect safely
 * using URLSearchParams parsing rather than fragile substring matching.
 */
function checkRecoveryUrl(): boolean {
  if (typeof window === 'undefined') return false;
  try {
    const hash = window.location.hash.startsWith('#') ? window.location.hash.slice(1) : window.location.hash;
    const hashParams = new URLSearchParams(hash);
    if (hashParams.get('type') === 'recovery') return true;
    const searchParams = new URLSearchParams(window.location.search);
    if (searchParams.get('type') === 'recovery') return true;
  } catch {
    return false;
  }
  return false;
}

export const AuthProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [user, setUser] = useState<User | null>(null);
  const [session, setSession] = useState<Session | null>(null);
  const [loading, setLoading] = useState<boolean>(true);
  const [isConfigured, setIsConfigured] = useState<boolean>(initialConfiguredStatus);
  const [isPasswordRecovery, setIsPasswordRecovery] = useState<boolean>(false);

  useEffect(() => {
    let isMounted = true;
    let authSubscription: { unsubscribe: () => void } | null = null;
    const hasRecoveryHint = checkRecoveryUrl();

    async function initAuth() {
      try {
        const client = await getOrInitSupabase();
        if (!isMounted) return;

        if (!client) {
          setIsConfigured(false);
          setLoading(false);
          return;
        }

        setIsConfigured(true);

        // Guard against race conditions between event listener and getSession()
        let initialEventFired = false;

        const { data } = client.auth.onAuthStateChange((event, newSession) => {
          if (!isMounted) return;
          initialEventFired = true;

          setSession(newSession);
          setUser(newSession?.user ?? null);
          setLoading(false);

          if (event === 'PASSWORD_RECOVERY') {
            setIsPasswordRecovery(true);
          } else if (event === 'SIGNED_OUT') {
            setIsPasswordRecovery(false);
          } else if (hasRecoveryHint && newSession && (event === 'INITIAL_SESSION' || event === 'SIGNED_IN')) {
            // Arrived via recovery link and a valid authenticated session is confirmed
            setIsPasswordRecovery(true);
          }
        });

        // If unmounted before listener registration completed (e.g. fast StrictMode remount)
        if (!isMounted) {
          data.subscription.unsubscribe();
          return;
        }

        authSubscription = data.subscription;

        // If onAuthStateChange has not fired an initial event yet, query getSession explicitly
        if (!initialEventFired) {
          const { data: sessionData, error } = await client.auth.getSession();
          if (!isMounted) return;

          if (!initialEventFired) {
            if (error) {
              console.warn('[CadetVerse Auth] Failed to restore session:', error.message);
            }
            setSession(sessionData.session);
            setUser(sessionData.session?.user ?? null);
            setLoading(false);

            if (hasRecoveryHint && sessionData.session) {
              setIsPasswordRecovery(true);
            }
          }
        }
      } catch (err) {
        console.error('[CadetVerse Auth] Initialization error:', err);
        if (isMounted) {
          setLoading(false);
        }
      }
    }

    initAuth();

    return () => {
      isMounted = false;
      if (authSubscription) {
        authSubscription.unsubscribe();
        authSubscription = null;
      }
    };
  }, []);

  const cadetUser = useMemo(() => {
    if (!user) return null;
    return buildCadetUser(user);
  }, [user]);

  const signInWithEmail = async (email: string, password: string) => {
    const client = await getOrInitSupabase();
    if (!client) {
      return { error: new Error('Supabase is not configured.') };
    }
    const { data, error } = await client.auth.signInWithPassword({
      email: email.trim(),
      password,
    });
    if (!error && data.session) {
      setSession(data.session);
      setUser(data.user);
    }
    return { error };
  };

  const signUpWithEmail = async (email: string, password: string, fullName?: string) => {
    const client = await getOrInitSupabase();
    if (!client) {
      return { error: new Error('Supabase is not configured.'), user: null };
    }

    const { data, error } = await client.auth.signUp({
      email: email.trim(),
      password,
      options: {
        data: fullName ? { full_name: fullName.trim() } : undefined,
      },
    });

    if (!error && data.session) {
      setSession(data.session);
      setUser(data.user);
    }

    return { error, user: data.user };
  };

  const signOut = async () => {
    const client = await getOrInitSupabase();
    if (!client) {
      setSession(null);
      setUser(null);
      setIsPasswordRecovery(false);
      return { error: null };
    }
    const { error } = await client.auth.signOut();
    setSession(null);
    setUser(null);
    setIsPasswordRecovery(false);
    return { error };
  };

  const sendPasswordResetEmail = async (email: string) => {
    const client = await getOrInitSupabase();
    if (!client) {
      return { error: new Error('Supabase is not configured.') };
    }

    const redirectUrl = typeof window !== 'undefined' ? window.location.origin : undefined;
    const { error } = await client.auth.resetPasswordForEmail(email.trim(), {
      redirectTo: redirectUrl,
    });
    return { error };
  };

  const updateUserPassword = async (newPassword: string) => {
    const client = await getOrInitSupabase();
    if (!client) {
      return { error: new Error('Supabase is not configured.') };
    }

    // Cryptographic / session verification: ensure an active, valid session exists
    const { data: sessionData, error: sessionError } = await client.auth.getSession();
    if (sessionError || !sessionData.session) {
      setIsPasswordRecovery(false);
      return {
        error: new Error(
          sessionError?.message ||
          'Password recovery session is invalid or has expired. Please request a new recovery link.'
        ),
      };
    }

    const { error } = await client.auth.updateUser({
      password: newPassword,
    });

    if (!error) {
      setIsPasswordRecovery(false);
      // Safely remove recovery parameters from location hash
      if (typeof window !== 'undefined' && window.location.hash.includes('type=recovery')) {
        window.history.replaceState(null, '', window.location.pathname);
      }
    }
    return { error };
  };

  const clearRecoveryMode = () => {
    setIsPasswordRecovery(false);
  };

  const value: AuthContextType = {
    user,
    session,
    cadetUser,
    loading,
    isConfigured,
    isPasswordRecovery,
    signInWithEmail,
    signUpWithEmail,
    signOut,
    sendPasswordResetEmail,
    updateUserPassword,
    clearRecoveryMode,
  };

  return <AuthContext.Provider value={value}>{children}</AuthContext.Provider>;
};

export function useAuth(): AuthContextType {
  const context = useContext(AuthContext);
  if (!context) {
    throw new Error('useAuth must be used within an AuthProvider');
  }
  return context;
}
